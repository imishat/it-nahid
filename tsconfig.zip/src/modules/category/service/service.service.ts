import { PrismaClient, Service } from "@prisma/client";

const prisma = new PrismaClient();
const createService = async (data: Service): Promise<Service> => {
  const result = await prisma.service.create({
    data,
  });
  return result;
};

const getAllService = async (option: any) => {
  const { shortBy, orderBy, serchTrem } = option;
  const result = await prisma.service.findMany({
    include: {
      category: true,
    },
    //data send by time or value
    orderBy:
      shortBy && orderBy
        ? {
            [shortBy]: orderBy,
          }
        : { createdAt: "desc" },

    where: {
      OR: [
        {
          category: {
            name: {
              contains: serchTrem,
              mode: "insensitive",
            },
          },
        },
        {
          title: {
            contains: serchTrem,
            mode: "insensitive",
          },
        },
      ],
    },
  });

  return result;
};
export const ServicePost = {
  createService,
  getAllService,
};
