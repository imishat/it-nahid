import { Request, Response } from "express";
import { ServicePost } from "./service.service";

const createService = async (req: Request, res: Response) => {
  try {
    const result = await ServicePost.createService(req.body);
    res.send({
      success: true,
      message: " Create Service Successfully!",
      data: result,
    });
  } catch (err) {
    res.send(err);
  }
};

const getAllCategory = async (req: Request, res: Response) => {
  console.log(req.query);
  const option = req.query;
  try {
    const result = await ServicePost.getAllService(option);
  } catch (err) {
    res.send(err);
  }
};
export const ServiceController = {
  createService,
};
