-- AlterTable
ALTER TABLE "Service" ALTER COLUMN "servicePicture" DROP NOT NULL;
