-- AlterTable
ALTER TABLE "Category" ALTER COLUMN "picture" DROP NOT NULL;
